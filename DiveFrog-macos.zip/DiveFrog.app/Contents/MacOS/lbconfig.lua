return {
	name = 'DiveFrog',
	config = '',
	platform = 'macos',
	version = '1.0.5',
	love = '11.5'
}
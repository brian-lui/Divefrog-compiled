return {
	name = 'DiveFrog',
	config = '',
	platform = 'win64',
	version = '1.0.5',
	love = '11.5'
}